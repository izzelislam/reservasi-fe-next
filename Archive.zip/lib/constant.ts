// export const baseUrl:string = 'http://localhost:8000/api/v1'
export const baseUrl:string = 'https://geni-reservasi.tvw-group.com/api/v1'